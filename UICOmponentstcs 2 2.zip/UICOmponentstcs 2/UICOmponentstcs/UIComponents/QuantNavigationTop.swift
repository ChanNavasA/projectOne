//
//  QuantNavigationTop.swift
//  UICOmponentstcs
//
//  Created by Bishwajit Dutta on 07/02/23.
//

import UIKit
import SnapKit

class QuantNavigationTop: UIView {

    let centerFactor = 50.0/375.0
    let imageFactor = 200.0/375.0
    let viewYOffset = 0.0
    
    private var colourGradients : [UIColor?]?
    private var viewImage : UIImage?
    private var viewStack : [UIView] = []
    
    init(colourList : [UIColor?], image : UIImage) {
        super.init(frame: .zero)
        self.colourGradients = colourList
        self.viewImage = image
        self.setupUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupUI() {
        let screenWidth = UIScreen.main.bounds.width
        let centerFactorOffset = (centerFactor * Double(screenWidth))
        let layerCenterOffset = centerFactorOffset / (Double(self.colourGradients?.count ?? 1))
        
        for i in 0 ... ((self.colourGradients?.count ?? 0) - 1) {
            if (i == (self.colourGradients?.count ?? 0) - 1) && viewImage != nil {
                let topImageView = TopBackgroundImageView.init(img: viewImage!)
                viewStack.append(topImageView)
            }
            let multiplicationFactor = Double((self.colourGradients?.count ?? 0) - i)
            let colourView = UIView(frame: .zero)
            colourView.backgroundColor = UIColor.clear
            colourView.alpha = 0.5
            // Calculating the center offset and drawing the arc(s)
            let circularPath = UIBezierPath(arcCenter: CGPoint(x: ((screenWidth/2.0 - centerFactorOffset) - (layerCenterOffset * multiplicationFactor)), y: (-(screenWidth/2.0) + viewYOffset) + (layerCenterOffset * multiplicationFactor)), radius: CGFloat(screenWidth), startAngle: CGFloat(0), endAngle: CGFloat(Double.pi * 2), clockwise: true)
            let shapeLayer = CAShapeLayer()
            shapeLayer.path = circularPath.cgPath
            // Change the fill colour
            shapeLayer.fillColor = self.colourGradients?[i]?.cgColor ?? UIColor.clear.cgColor
            colourView.layer.addSublayer(shapeLayer)
            
            viewStack.append(colourView)
        }
        layoutUI()
    }
    
    private func layoutUI() {
        for view in self.viewStack {
            self.addSubview(view)
            if view is TopBackgroundImageView {
                view.snp.makeConstraints { make in
                    make.width.equalToSuperview()
                    make.height.equalTo(UIScreen.main.bounds.width * imageFactor)
                }
            } else {
                view.snp.makeConstraints { make in
                    make.width.equalToSuperview()
                    make.height.equalTo(view.snp.width)
                }
            }
        }
    }
}


fileprivate class TopBackgroundImageView : UIImageView {
    
    private lazy var imageView : UIImageView = {
        let imgView = UIImageView(frame: .zero)
        imgView.backgroundColor = UIColor.clear
        imgView.contentMode = .scaleAspectFit
        imgView.clipsToBounds = true
        return imgView
    }()
    
    init(img: UIImage) {
        super.init(frame: .zero)
        self.imageView.image = img
        self.layoutUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func layoutUI() {
        self.addSubview(imageView)
        imageView.snp.makeConstraints { make in
            make.width.height.equalToSuperview().inset(5.0)
            make.centerX.equalToSuperview()
            make.top.equalToSuperview().offset(20.0)
        }
    }
}
