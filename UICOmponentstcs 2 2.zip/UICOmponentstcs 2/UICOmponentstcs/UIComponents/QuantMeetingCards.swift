//
//  QuantMeetingCards.swift
//  UICOmponentstcs
//
//  Created by Bishwajit Dutta on 03/02/23.
//

import UIKit

class QuantMeetingCards: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
