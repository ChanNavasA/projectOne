//
//  QuantImageCardView.swift
//  UICOmponentstcs
//
//  Created by Bishwajit Dutta on 31/01/23.
//

import UIKit
import SnapKit

class QuantImageCardView: UIView {
    
    private let cardWidthSizeFactor = 0.5
    private let cardHeightSizeFactor = 0.75
    private let imageViewMargineOffset = 1.5
    private let viewHeight = 175.0
    private let lblOffset : CGFloat = 10.0
    
    private lazy var cardImageView: UIImageView = {
        let imgView = UIImageView(frame: .zero)
        imgView.backgroundColor = UIColor.clear
        imgView.contentMode = .scaleToFill
        imgView.layer.cornerRadius = 5.0
        return imgView
    }()
    
    private lazy var imgHolderView: UIView = {
        let view = UIView(frame: .zero)
        view.layer.cornerRadius = 5.0
        view.backgroundColor = UIColor.clear
        view.clipsToBounds = true
        return view
    }()
    
    private lazy var backgroundView: UIView = {
        let view = UIView(frame: .zero)
        view.layer.cornerRadius = 5.0
        view.backgroundColor = UIColor.white
        view.layer.masksToBounds = false
        view.layer.shadowColor = UIColor.black.cgColor
        view.layer.shadowOpacity = 0.5
        view.layer.shadowOffset = .zero
        view.layer.shadowRadius = 20
        view.layer.shouldRasterize = true
        view.layer.rasterizationScale = UIScreen.main.scale
        return view
    }()
    
    private lazy var cardNameLbl: UILabel = {
        let label = UILabel(frame: .zero)
        label.textAlignment = .center
        label.textColor = UIColor.gray
        label.numberOfLines = 1
        label.font = UIFont.systemFont(ofSize: 15.0, weight: .semibold)
        return label
    }()
    
    private var cardImage: UIImage?
    private var cardName: String?
    private var optionSelectHandler : ((Int) -> Void)?
    private var itemTagNumber : Int?
    
    init(cardImage: UIImage?, cardName : String?, itemTag: Int?, optionSelectHandler: ((Int) -> Void)?) {
        super.init(frame: .zero)
        self.cardImage = cardImage
        self.cardName = cardName
        self.itemTagNumber = itemTag
        self.optionSelectHandler = optionSelectHandler
        self.setupView()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupView() {
        self.cardImageView.image = self.cardImage
        self.cardNameLbl.text = self.cardName?.uppercased()
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(imageTapped(tapGestureRecognizer:)))
        self.cardImageView.isUserInteractionEnabled = true
        self.cardImageView.addGestureRecognizer(tapGestureRecognizer)
        self.layoutUI()
    }
    
    private func layoutUI() {
        self.addSubview(backgroundView)
        self.imgHolderView.addSubview(cardImageView)
        self.backgroundView.addSubview(imgHolderView)
        self.addSubview(cardNameLbl)
        self.snp.makeConstraints { make in
            make.height.equalTo(viewHeight)
        }
        self.backgroundView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(4.0)
            make.width.equalToSuperview().multipliedBy(cardWidthSizeFactor)
            make.height.equalTo(backgroundView.snp.width).multipliedBy(cardHeightSizeFactor)
            make.centerX.equalToSuperview()
        }
        self.cardNameLbl.snp.makeConstraints { make in
            make.top.equalTo(backgroundView.snp.bottom).offset(lblOffset)
            make.bottom.lessThanOrEqualTo(-imageViewMargineOffset)
            make.leading.equalToSuperview().offset(lblOffset)
            make.trailing.equalToSuperview().offset(-lblOffset)
            make.height.equalTo(20.0)
        }
        self.imgHolderView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(imageViewMargineOffset)
            make.bottom.equalToSuperview().offset(-imageViewMargineOffset)
            make.leading.equalToSuperview().offset(imageViewMargineOffset)
            make.trailing.equalToSuperview().offset(-imageViewMargineOffset)
        }
        
        self.cardImageView.snp.makeConstraints { make in
            make.leading.trailing.top.bottom.equalToSuperview()
        }
    }
    
    @objc func imageTapped(tapGestureRecognizer: UITapGestureRecognizer) {
        if let handler = self.optionSelectHandler {
            handler(itemTagNumber ?? 0)
        }
    }
}
