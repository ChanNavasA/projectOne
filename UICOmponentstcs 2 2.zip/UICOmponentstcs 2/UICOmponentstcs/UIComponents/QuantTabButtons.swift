//
//  QuantTabButtons.swift
//  UICOmponentstcs
//
//  Created by Bishwajit Dutta on 01/02/23.
//

import UIKit
import SnapKit

struct QuantTabButtonsData {
    var menuOptionSpec : (buttonNames : [String], buttonIcons : [UIImage], notificationCounter : [String])
    var headerText : String
    var dividerColour : UIColor
    var menuTappedHandler : ((Int) -> Void)
}

class QuantTabButtons: UIView {
    // Create a variable with the struct and create the view on did set
    
    private let menuViewHeight = 70.0
    private let stackViewSpacing = 30.0
    
    // Shadow is added to show the view as floating
    private lazy var backgroundView: UIView = {
        let view = UIView(frame: .zero)
        view.layer.cornerRadius = 5.0
        view.backgroundColor = UIColor.white
        view.layer.masksToBounds = false
        view.layer.shadowColor = UIColor.black.cgColor
        view.layer.shadowOpacity = 0.5
        view.layer.shadowOffset = .zero
        view.layer.shadowRadius = 10
        view.layer.shouldRasterize = true
        view.layer.rasterizationScale = UIScreen.main.scale
        return view
    }()
    
    private lazy var dividerView: UIView = {
        let view = UIView(frame: .zero)
        view.snp.makeConstraints { make in
            make.height.equalTo(menuViewHeight)
            make.width.equalTo(1.0)
        }
        return view
    }()
    
    private lazy var headerNameLbl: UILabel = {
        let label = UILabel(frame: .zero)
        label.textAlignment = .left
        label.textColor = UIColor.gray
        label.numberOfLines = 1
        label.font = UIFont.systemFont(ofSize: 13.0, weight: .regular)
        return label
    }()
    
    // Stack view need to be placed on top of the background view so that the button views and the devider view  can be adjusted
    
    private lazy var menuStackView = UIStackView()
    
    private var quantTabButtonsData : QuantTabButtonsData?
    
    init(quantTabButtonsData: QuantTabButtonsData) {
        super.init(frame: .zero)
        self.quantTabButtonsData = quantTabButtonsData
        self.setupUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupUI() {
        self.backgroundColor = UIColor.clear
        // Itrate through menu option specs and add the views in the stack view
        // we cna make it more robust if we check for both name and icons. Which ever is grater use that
        self.dividerView.backgroundColor = quantTabButtonsData?.dividerColour ?? UIColor.black
        var arrangedSubviews : [UIView] = []
        for i in 0 ... ((quantTabButtonsData?.menuOptionSpec.buttonNames.count ?? 0) - 1) {
            let optionMenuView = QuantMenuOption.init(buttonName: quantTabButtonsData?.menuOptionSpec.buttonNames[i] ?? "",
                                                      buttonIcon: quantTabButtonsData?.menuOptionSpec.buttonIcons[i],
                                                      notificationCounter: quantTabButtonsData?.menuOptionSpec.notificationCounter[i] ?? "",
                                                      itemTagNumber: i, optionSelectHandler: quantTabButtonsData?.menuTappedHandler)
            
            arrangedSubviews.append(optionMenuView)
            if i < ((quantTabButtonsData?.menuOptionSpec.buttonNames.count ?? 0) - 1) {
                let view = UIView(frame: .zero)
                view.backgroundColor = quantTabButtonsData?.dividerColour ?? UIColor.black
                arrangedSubviews.append(view)
            }
        }
        self.headerNameLbl.text = quantTabButtonsData?.headerText
        self.menuStackView = UIStackView(arrangedSubviews: arrangedSubviews)
        self.menuStackView.spacing = stackViewSpacing
        self.menuStackView.axis = .horizontal
        self.menuStackView.alignment = .center
        for view in self.menuStackView.arrangedSubviews {
            if !(view is QuantMenuOption) {
                view.snp.makeConstraints { make in
                    make.width.equalTo(1.0)
                    make.height.equalTo(menuViewHeight - 30.0)
                }
            }
        }
        self.layoutUI()
    }
    
    private func layoutUI() {
        self.addSubview(self.backgroundView)
        self.backgroundView.addSubview(self.menuStackView)
        if quantTabButtonsData?.headerText != "" {
            self.addSubview(self.headerNameLbl)
        }
        
        if quantTabButtonsData?.headerText != "" {
            self.snp.makeConstraints { make in
                make.height.equalTo(menuViewHeight + 30.0)
            }
            self.headerNameLbl.snp.makeConstraints { make in
                make.leading.trailing.equalToSuperview().inset(8.0)
                make.top.equalToSuperview().offset(8.0)
                make.height.equalTo(20.0)
            }
            self.backgroundView.snp.makeConstraints { make in
                make.top.equalTo(headerNameLbl.snp.bottom).offset(5.0)
                make.bottom.equalToSuperview()
                make.leading.greaterThanOrEqualToSuperview().offset(8.0)
                make.trailing.lessThanOrEqualToSuperview().offset(-8.0)
            }
            self.menuStackView.snp.makeConstraints { make in
                make.leading.trailing.equalToSuperview().inset(stackViewSpacing / 2.0)
                make.bottom.top.equalToSuperview().inset(5.0)
                
            }
            
        } else {
            self.backgroundView.snp.makeConstraints { make in
                make.top.bottom.equalToSuperview()
                make.leading.greaterThanOrEqualToSuperview().offset(8.0)
                make.trailing.lessThanOrEqualToSuperview().offset(-8.0)
            }
            self.snp.makeConstraints { make in
                make.height.equalTo(menuViewHeight)
            }
            self.menuStackView.snp.makeConstraints { make in
                make.leading.trailing.equalToSuperview().inset(stackViewSpacing / 2.0)
                make.top.bottom.equalToSuperview().inset(5.0)
            }
        }
        
    }
}

fileprivate class QuantMenuOption: UIView {
    
    private let counterlabelHeight = 18.0
    private let menuheight = 60.0
    
    private lazy var menuOptionHolderView: UIView = {
        let view = UIView(frame: .zero)
        view.backgroundColor = UIColor.clear
        return view
    }()
    
    private let menuImageView: UIImageView = {
        let imgView = UIImageView(frame: .zero)
        imgView.backgroundColor = UIColor.clear
        imgView.contentMode = .scaleAspectFit
        return imgView
    }()
    
    private lazy var menuNameLbl: UILabel = {
        let label = UILabel(frame: .zero)
        label.textAlignment = .center
        label.textColor = UIColor.purple
        label.numberOfLines = 1
        label.minimumScaleFactor = 0.5
        label.font = UIFont.systemFont(ofSize: 10.0, weight: .semibold)
        return label
    }()
    
    private lazy var counterLbl: UILabel = {
        let label = UILabel(frame: .zero)
        label.textAlignment = .center
        label.textColor = UIColor.white
        label.backgroundColor = UIColor.black
        label.numberOfLines = 1
        label.font = UIFont.systemFont(ofSize: 10.0, weight: .regular)
        label.snp.makeConstraints { make in
            make.height.equalTo(counterlabelHeight)
        }
        label.layer.cornerRadius = 9.0
        label.layer.masksToBounds = true
        return label
    }()
    
    private var buttonName : String?
    private var buttonIcon : UIImage?
    private var notificationCounter : String?
    private var itemTagNumber : Int?
    private var optionSelectHandler : ((Int) -> Void)?
    
    init(buttonName: String, buttonIcon: UIImage?, notificationCounter: String, itemTagNumber: Int, optionSelectHandler : ((Int) -> Void)?) {
        super.init(frame: .zero)
        self.buttonName = buttonName
        self.buttonIcon = buttonIcon
        self.notificationCounter = notificationCounter
        self.itemTagNumber = itemTagNumber
        self.optionSelectHandler = optionSelectHandler
        self.setupUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupUI() {
        self.menuImageView.image = self.buttonIcon ?? UIImage(named: "")
        self.menuNameLbl.text = self.buttonName
        self.counterLbl.text = self.notificationCounter
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(optionTapped(tapGestureRecognizer:)))
        self.isUserInteractionEnabled = true
        self.addGestureRecognizer(tapGestureRecognizer)
        self.layoutUI()
    }
    
    private func layoutUI() {
        self.addSubview(self.menuOptionHolderView)
        self.menuOptionHolderView.addSubview(menuImageView)
        self.menuOptionHolderView.addSubview(menuNameLbl)
        self.snp.makeConstraints { make in
            make.height.width.equalTo(menuheight)
        }
        // Add background holder view same as the super view
        self.menuOptionHolderView.snp.makeConstraints { make in
            make.leading.trailing.top.bottom.equalToSuperview()
        }
        // Then layout the sub views of the background view
        self.menuNameLbl.snp.makeConstraints { make in
            make.leading.trailing.equalToSuperview()
            make.bottom.equalToSuperview().offset(-3.0)
            make.height.equalTo(18.0)
        }
        
        self.menuImageView.snp.makeConstraints { make in
            make.bottom.equalTo(self.menuNameLbl.snp.top).offset(-5.0)
            make.leading.top.equalToSuperview().offset(5.0)
            make.trailing.equalToSuperview().offset(-5.0)
        }
        if self.notificationCounter != "" {
            // add the constraint here
            self.menuOptionHolderView.addSubview(self.counterLbl)
            self.counterLbl.snp.makeConstraints { make in
                make.trailing.equalToSuperview()
                make.top.equalToSuperview()
                if notificationCounter?.count ?? 0 > 2 {
                    make.width.equalTo(counterlabelHeight + 6.0)
                } else {
                    make.width.equalTo(counterLbl.snp.height)
                }
            }
        }
    }
    
    @objc func optionTapped(tapGestureRecognizer: UITapGestureRecognizer) {
        if let handler = self.optionSelectHandler {
            handler(itemTagNumber ?? 0)
        }
    }
}
