//
//  QuantTextView.swift
//  UICOmponentstcs
//
//  Created by Bishwajit Dutta on 30/01/23.
//

import UIKit
import SnapKit

class QuantTextView: UIView {
    
    private let viewOffset : CGFloat = 8.0
    private let imageDimention : CGFloat = 38.0
    private let marginOffset : CGFloat = 1.5
    
    // Text field
    // Currently adding the properties directly. Can have View Model class for text field for customizing the view
    lazy var quantTextField: UITextView = {
        let textView = UITextView(frame: .zero)
        textView.textAlignment = .left
        textView.layer.cornerRadius = 5.0
        textView.isScrollEnabled = false
        textView.font = UIFont.systemFont(ofSize: 18.0,
                                          weight: .regular)
        textView.textAlignment = .left
        textView.textContainer.lineBreakMode = .byWordWrapping
        textView.delegate = self
        return textView
    }()
    
    
    private lazy var iconView: UIImageView = {
        let inlineImageView = UIImageView(frame: .zero)
        inlineImageView.image = #imageLiteral(resourceName: "searchIcon")
        inlineImageView.backgroundColor = UIColor.white
        inlineImageView.contentMode = .scaleAspectFit
        inlineImageView.layer.cornerRadius = 5.0
        return inlineImageView
    }()
    
    private lazy var backgroundView: UIView = {
        let view = UIView(frame: .zero)
        view.layer.cornerRadius = 5.0
        return view
    }()
    
    private var placeHolderText : String?
    private var isSearchIconEnabled : Bool?
    private var isPasswordEnabled : Bool?
    private var keyboardType : UIKeyboardType?
    private var borderColour : UIColor?
    
    init(placeHolderText : String? = "", isSearchIconEnabled : Bool? = false, isPasswordEnabled : Bool? = false, keyboardType : UIKeyboardType? = .default, bordercolour : UIColor? = UIColor.black) {
        super.init(frame: .zero)
        self.placeHolderText = placeHolderText
        self.isSearchIconEnabled = isSearchIconEnabled
        self.isPasswordEnabled = isSearchIconEnabled
        self.keyboardType = keyboardType
        self.borderColour = bordercolour
        self.setupUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    // Update the view with init Data
    private func setupUI() {
        self.quantTextField.isSecureTextEntry = isPasswordEnabled ?? false
        self.quantTextField.text = placeHolderText ?? ""
        if placeHolderText != "" {
            self.quantTextField.textColor = UIColor.lightGray
        }
        self.quantTextField.keyboardType = keyboardType ?? .default
        self.backgroundView.backgroundColor = borderColour ?? .black
        layoutUI()
    }
    
    // This method will be used for laying out the components
    private func layoutUI() {
        self.addSubview(self.backgroundView)
        self.backgroundView.addSubview(self.quantTextField)
        self.snp.makeConstraints { make in
            make.height.equalTo(40.0)
        }
        self.backgroundView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.bottom.equalToSuperview()
            make.leading.equalToSuperview().offset(viewOffset)
            make.trailing.equalToSuperview().offset(-viewOffset)
        }
        
        self.quantTextField.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(marginOffset)
            make.bottom.equalToSuperview().offset(-marginOffset)
            make.trailing.equalToSuperview().offset(-marginOffset)
        }
        if isSearchIconEnabled ?? false {
            self.backgroundView.addSubview(self.iconView)
            self.iconView.snp.makeConstraints { make in
                make.leading.equalToSuperview().offset(marginOffset)
                make.width.equalTo(imageDimention)
                make.height.equalTo(imageDimention)
                make.centerY.equalToSuperview()
            }
            
            self.quantTextField.snp.makeConstraints { make in
                make.leading.equalTo(iconView.snp.trailing).offset(marginOffset)
            }
        } else {
            self.quantTextField.snp.makeConstraints { make in
                make.leading.equalToSuperview().offset(marginOffset)
            }
        }
    }
}

// MARK: TextView delegate
extension QuantTextView : UITextViewDelegate {
    
    // This is done for showing and removing placeholder text
    func textViewDidBeginEditing(_ textView: UITextView) {
        if textView.textColor == UIColor.lightGray {
            textView.text = nil
            textView.textColor = UIColor.black
        }
        self.backgroundView.backgroundColor = UIColor.purple
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        if textView.text.isEmpty {
            textView.text = placeHolderText ?? ""
            textView.textColor = UIColor.lightGray
        }
        self.backgroundView.backgroundColor = borderColour ?? .black
    }
}
