//
//  QuantExpoOneToOneViewController.swift
//  UICOmponentstcs
//
//  Created by Local User on 08/02/23.
//

import UIKit

class QuantExpoOneToOneViewController: UIViewController {

    @IBOutlet weak var oneToOneCollectionView: UICollectionView!
    
    enum Section: Int, CaseIterable {
        case oneToOne
    }

    var dataSource: UICollectionViewDiffableDataSource<Section, Int>! = nil
    
    init() {
        super.init(nibName: "QuantExpoOneToOneViewController", bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        NotificationCenter.default
                          .addObserver(self,
                                       selector: #selector(self.popToViewController),
                         name: NSNotification.Name ("popToHomeViewController"),                                           object: nil)
        oneToOneCollectionView?.collectionViewLayout = createLayout()
        oneToOneCollectionView?.register(UINib(nibName: "OneToOneCell", bundle: nil), forCellWithReuseIdentifier: OneToOneCell.cellIdentifier)
        self.configurationDataSource()
        // Do any additional setup after loading the view.
    }

    @objc private func popToViewController() {
        print("check")
        self.navigationController?.popViewController(animated: true)
    }
    private func configurationDataSource() {
        
        dataSource = UICollectionViewDiffableDataSource<Section, Int>(collectionView: oneToOneCollectionView) { (collectionView, indexPath, number) -> UICollectionViewCell? in
            
            if let section = Section(rawValue: indexPath.section) {
                switch section {
                case .oneToOne:
                    guard let cell = self.oneToOneCollectionView?.dequeueReusableCell(withReuseIdentifier: OneToOneCell.cellIdentifier, for: indexPath) as? OneToOneCell else {
                        fatalError("cannot create cell")
                    }
//                    cell.boothName.text = "\(number)"
                    cell.shadowDecorate()
                    return cell
                }
            }
            return UICollectionViewCell()
        }
    var snapshot = NSDiffableDataSourceSnapshot<Section, Int>()
    snapshot.appendSections(Section.allCases)
    snapshot.appendItems([1,2,3,4,5,6,7,8,9,10], toSection: .oneToOne)
    dataSource.apply(snapshot, animatingDifferences: true)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}


extension QuantExpoOneToOneViewController {
    
    private func configureOneToOneData() -> NSCollectionLayoutSection {
        // 1 Setup the Item
        let itemSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0), heightDimension: .absolute(80))
        let item = NSCollectionLayoutItem(layoutSize: itemSize)
        item.contentInsets = NSDirectionalEdgeInsets(top: 10, leading: 10, bottom: 2, trailing: 10)
        
        // 2 Setup the Group
        let groupSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0), heightDimension: .absolute(80))
        let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize, subitems: [item])
        group.contentInsets = NSDirectionalEdgeInsets(top: 20, leading: 20, bottom: 20, trailing: 20)
        
        // 3 Setup the Section
        let section = NSCollectionLayoutSection(group: group)
        section.orthogonalScrollingBehavior = .none
        return section
    }

    private func createLayout() ->  UICollectionViewLayout {
        return UICollectionViewCompositionalLayout { (sectionNumber, env) -> NSCollectionLayoutSection? in
            guard let sectionKind = Section(rawValue: sectionNumber) else { return nil }
             switch sectionKind {
             case .oneToOne:
                 return self.configureOneToOneData()
             }
           }
    }
}
