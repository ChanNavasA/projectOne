//
//  QuantExpoBoothViewController.swift
//  UICOmponentstcs
//
//  Created by Local User on 08/02/23.
//

import UIKit

class QuantExpoBoothViewController: QuantBaseViewController {

    @IBOutlet weak var boothCollectionView: UICollectionView!
    
    enum Section: Int, CaseIterable {
        case Booth
    }

    var dataSource: UICollectionViewDiffableDataSource<Section, Int>! = nil
    init() {
        super.init(nibName: "QuantExpoBoothViewController", bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        NotificationCenter.default
            .addObserver(self,
                         selector: #selector(self.popToViewController),
                         name: NSNotification.Name ("popToHomeViewController"),                                           object: nil)

        boothCollectionView?.collectionViewLayout = createLayout()
        boothCollectionView?.register(UINib(nibName: "BoothCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: BoothCollectionViewCell.cellIdentifier)
        self.configurationDataSource()
        // Do any additional setup after loading the view.
    }

    func setupUI() {
        
    }
    
    func layoutUI() {
        
    }
    @objc private func popToViewController() {
        print("check")
        self.navigationController?.popViewController(animated: true)
    }
    private func configurationDataSource() {
        dataSource = UICollectionViewDiffableDataSource<Section, Int>(collectionView: boothCollectionView!) { (collectionView, indexPath, number) -> UICollectionViewCell? in
            
            if let section = Section(rawValue: indexPath.section) {
                switch section {
                case .Booth:
                    guard let cell = self.boothCollectionView?.dequeueReusableCell(withReuseIdentifier: BoothCollectionViewCell.cellIdentifier, for: indexPath) as? BoothCollectionViewCell else {
                        fatalError("cannot create cell")
                    }
                    cell.boothName.text = "\(number)"
                    return cell
                    
//                case .oneToOne:
//                    guard let cell = self.boothCollectionView?.dequeueReusableCell(withReuseIdentifier: OneToOneCell.cellIdentifier, for: indexPath) as? OneToOneCell else {
//                        fatalError("cannot create cell")
//                    }
////                    cell.boothName.text = "\(number)"
//                    cell.shadowDecorate()
//                    return cell
                }
            }
            return UICollectionViewCell()
        }
        
//        var snapshot = NSDiffableDataSourceSnapshot<Section, Int>()
//        snapshot.appendSections([.Booth])
//        snapshot.appendItems(Array(0..<20))
//        dataSource.apply(snapshot, animatingDifferences: false)
        
        

    
    var snapshot = NSDiffableDataSourceSnapshot<Section, Int>()
    snapshot.appendSections(Section.allCases)
    snapshot.appendItems([1,2,3,4,5,6,7,8,9,10], toSection: .Booth)
//    snapshot.appendItems(Array(5...9), toSection: .oneToOne)
    dataSource.apply(snapshot, animatingDifferences: true)
    }
    

}

extension QuantExpoBoothViewController {
    
    private func configureBoothData() -> NSCollectionLayoutSection {
        let itemSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(0.3), heightDimension: .fractionalHeight(1.0))
        let item = NSCollectionLayoutItem(layoutSize: itemSize)
        let groupSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0), heightDimension: .fractionalHeight(0.2))
        let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize, subitem: item, count: 3)
        group.contentInsets = NSDirectionalEdgeInsets(top: 10, leading: 10, bottom: 10, trailing: 10)
        let section = NSCollectionLayoutSection(group: group)
        section.interGroupSpacing = 5
        return section
    }

    private func createLayout() ->  UICollectionViewLayout {
        return UICollectionViewCompositionalLayout { (sectionNumber, env) -> NSCollectionLayoutSection? in

            guard let sectionKind = Section(rawValue: sectionNumber) else { return nil }

             switch sectionKind {
             case .Booth:
                 return self.configureBoothData()
             }
           }
    }
}
