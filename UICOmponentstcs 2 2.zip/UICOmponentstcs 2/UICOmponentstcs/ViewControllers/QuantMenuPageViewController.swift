//
//  QuantMenuPageViewController.swift
//  UICOmponentstcs
//
//  Created by Bishwajit Dutta on 07/02/23.
//

import UIKit
import SnapKit

class QuantMenuPageViewController: QuantBaseViewController {
    
    private let stackViewSpacing = (UIScreen.main.bounds.height > 670) ? 30.0 : 0.0
    private let stackViewTopOffsetMultiplyer = 0.224
    private let stackViewBottomOffsetMultiplyer = -0.044
    
    private lazy var menuStackView = UIStackView()
    
    private var quantTabButtons : QuantTabButtons?
    
    private lazy var headerLabel : UILabel = {
        let lbl = UILabel(frame: .zero)
        lbl.numberOfLines = 0
        lbl.textColor = UIColor.white
        lbl.textAlignment = .center
        lbl.font = .systemFont(ofSize: 24.0, weight: .semibold)
        lbl.snp.makeConstraints { make in
            make.height.equalTo(60.0)
        }
        return lbl
    }()
    
    init() {
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setupUI()
    }
    
    
    func setupUI() {
        // TODO: Get the rendering engine
        // Get the name and icons of the card and the menu items
        // Directly calling the layout ui as we dont have any icons and images with us as of now
        var arrangedSubviews : [UIView] = []
        // ====================== This part will be done by rendering engine ===================================
        let navTopView = QuantNavigationTop.init(colourList: [UIColor(hex: "#A54CAFFF"), UIColor(hex: "#C659C9FF"), UIColor(hex: "#D863DBFF")], image: UIImage())
        self.view.addSubview(navTopView)
        self.headerLabel.text = "Welcome Mr. ABCD"
        let menuOneView = QuantImageCardView(cardImage: UIImage(named: "sample"), cardName: "BOOTH AND DIGITAL STORE",itemTag: 1) { option in
            // TODO: Handle the tap gesture call
            NavigationCoordinator.moveToNextController(navigationController: self.navigationController ?? UINavigationController(), initiatingController: QuantViewControllers.MenuPageViewController, option: option)
        }
        arrangedSubviews.append(menuOneView)
        let menuTwoView = QuantImageCardView(cardImage: UIImage(named: "sample"), cardName: "PLAN 1: 1 CONNECT",itemTag: 2) { option in
            // TODO: Handle the tap gesture call
            NavigationCoordinator.moveToNextController(navigationController: self.navigationController ?? UINavigationController(), initiatingController: QuantViewControllers.MenuPageViewController, option: option)
        }
        arrangedSubviews.append(menuTwoView)
        
        let quantTabButtonsData = QuantTabButtonsData(menuOptionSpec: (buttonNames: ["Inbox", "Agenda", "Floor Plan"], buttonIcons: [#imageLiteral(resourceName: "searchIcon"),#imageLiteral(resourceName: "searchIcon"),#imageLiteral(resourceName: "searchIcon")], notificationCounter: ["1", "", ""]), headerText: "", dividerColour: UIColor.lightGray, menuTappedHandler: { option in
            
        })
        self.quantTabButtons = QuantTabButtons(quantTabButtonsData: quantTabButtonsData)
        self.menuStackView = UIStackView(arrangedSubviews: arrangedSubviews)
        self.menuStackView.spacing = stackViewSpacing
        self.menuStackView.axis = .vertical
        self.menuStackView.alignment = .center
        self.layoutUI()
    }
    
    func layoutUI() {
        self.view.addSubview(headerLabel)
        for view in self.view.subviews {
            if view is QuantNavigationTop {
                view.snp.makeConstraints { make in
                    make.centerX.equalToSuperview()
                    make.width.equalToSuperview()
                    make.height.equalTo(view.snp.width)
                }
            }
            if view is UILabel {
                view.snp.makeConstraints { make in
                    make.leading.trailing.equalToSuperview()
                    make.top.equalToSuperview().offset(50.0)
                }
            }
        }
        if let tabbuttons = self.quantTabButtons {
            self.view.addSubview(tabbuttons)
            self.view.addSubview(self.menuStackView)
            tabbuttons.snp.makeConstraints { make in
                make.centerX.equalToSuperview()
                make.bottom.equalToSuperview().offset(-30.0)
            }
            
            self.menuStackView.snp.makeConstraints { make in
                make.bottom.equalTo(tabbuttons.snp.top).offset(stackViewBottomOffsetMultiplyer * UIScreen.main.bounds.height)
                make.top.equalToSuperview().offset(stackViewTopOffsetMultiplyer * UIScreen.main.bounds.height)
                make.leading.equalToSuperview().offset(30.0)
                make.trailing.equalToSuperview().offset(-30.0)
            }
            
            for view in self.menuStackView.arrangedSubviews {
                if view is QuantImageCardView {
                    view.snp.makeConstraints { make in
                        make.centerX.equalToSuperview()
                        make.height.equalTo(175.0)
                    }
                }
            }
        }
    }
}
