//
//  QuantLoginViewController.swift
//  UICOmponentstcs
//
//  Created by Bishwajit Dutta on 07/02/23.
//

import UIKit
import SnapKit

class QuantLoginViewController: QuantBaseViewController {
    
    private let stackViewSpacing = 30.0
    private let formHeight = 490.0
    private let marginOffset = 50.0
    
    private lazy var placeholderview : UIView = {
        let view = UIView(frame: .zero)
        view.backgroundColor = UIColor.white
        view.layer.cornerRadius = 5.0
        view.clipsToBounds = true
        view.layer.masksToBounds = false
        view.layer.shadowColor = UIColor.black.cgColor
        view.layer.shadowOpacity = 0.5
        view.layer.shadowOffset = .zero
        view.layer.shadowRadius = 20
        view.layer.shouldRasterize = true
        view.layer.rasterizationScale = UIScreen.main.scale
        return view
    }()
    
    private lazy var headerLabel : UILabel = {
        let lbl = UILabel(frame: .zero)
        lbl.numberOfLines = 0
        lbl.textColor = UIColor.black
        lbl.snp.makeConstraints { make in
            make.height.equalTo(60.0)
        }
        return lbl
    }()
    
    private lazy var otpAuthLabel : UILabel = {
        let lbl = UILabel(frame: .zero)
        lbl.numberOfLines = 1
        lbl.text = "One Time Auth Code"
        lbl.textColor = UIColor.lightGray
        lbl.textAlignment = .center
        lbl.font = .systemFont(ofSize: 16.0, weight: .semibold)
        lbl.snp.makeConstraints { make in
            make.height.equalTo(20.0)
        }
        return lbl
    }()
    
    private lazy var submitBtn : UIButton = {
        let btn = UIButton(type: .custom)
        btn.setTitle("Check-in", for: .normal)
        btn.titleLabel?.font = .systemFont(ofSize: 16, weight: .semibold)
        btn.setTitleColor(UIColor.white, for: .normal)
        btn.backgroundColor = UIColor.purple
        btn.layer.cornerRadius = 10.0
        return btn
    }()
    
    private lazy var formStackView = UIStackView()
    private var viewBottomOffset : CGFloat = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Notifications for when the keyboard opens/closes
        NotificationCenter.default.addObserver(self, selector: #selector(self.keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)

        NotificationCenter.default.addObserver(self, selector: #selector(self.keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setupUI()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.viewBottomOffset = self.placeholderview.frame.origin.y + self.placeholderview.frame.size.height
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    func setupUI() {
        // TODO: Get the plist file from rendering engine. Currently adding the components directly
        var arrangedSubviews : [UIView] = []
        // ====================== This part will be done by rendering engine ===================================
        let lineOneAttrString = NSAttributedString(string: "Welcome Summit", attributes: [ NSAttributedString.Key.font: UIFont.systemFont(ofSize: 24.0, weight: .semibold)])
        let lineTwoAttrString = NSAttributedString(string: "\n Quant Internship - London 2023", attributes: [ NSAttributedString.Key.font: UIFont.systemFont(ofSize: 14.0, weight: .regular), NSAttributedString.Key.foregroundColor: UIColor.gray])
        let combination = NSMutableAttributedString()
        combination.append(lineOneAttrString)
        combination.append(lineTwoAttrString)
        self.headerLabel.attributedText = combination
        arrangedSubviews.append(self.headerLabel)
        let nameTextField = QuantTextView(placeHolderText: "Name", bordercolour: UIColor.lightGray)
        arrangedSubviews.append(nameTextField)
        let emailTextField = QuantTextView(placeHolderText: "Email", keyboardType: .emailAddress, bordercolour: UIColor.lightGray)
        arrangedSubviews.append(emailTextField)
        let departmentTextField = QuantTextView(placeHolderText: "Department", bordercolour: UIColor.lightGray)
        arrangedSubviews.append(departmentTextField)
        arrangedSubviews.append(otpAuthLabel)
        let otpStackView = QuantOTPStackView(numberOfFields: 4)
        otpStackView.delegate = self
        otpStackView.setAllFieldColor(color: UIColor.lightGray)
        arrangedSubviews.append(otpStackView)
        arrangedSubviews.append(submitBtn)
        submitBtn.addTarget(self, action: #selector(onButtonClicked), for: .touchUpInside)
        let navTopView = QuantNavigationTop.init(colourList: [UIColor(hex: "#A54CAFFF"), UIColor(hex: "#C659C9FF"), UIColor(hex: "#D863DBFF")], image: UIImage())
        self.view.addSubview(navTopView)
        // =============================== End of rendering engine part ==================================================
        self.formStackView = UIStackView(arrangedSubviews: arrangedSubviews)
        self.formStackView.spacing = stackViewSpacing
        self.formStackView.axis = .vertical
        self.formStackView.alignment = .center
        self.layoutUI()
    }
    
    func layoutUI() {
        self.placeholderview.addSubview(self.formStackView)
        self.view.addSubview(placeholderview)
        for view in self.view.subviews {
            if view is QuantNavigationTop {
                view.snp.makeConstraints { make in
                    make.centerX.equalToSuperview()
                    make.width.equalToSuperview()
                    make.height.equalTo(view.snp.width)
                }
            }
        }
        self.formStackView.snp.makeConstraints { make in
            make.leading.trailing.equalToSuperview()
            make.top.bottom.equalToSuperview().inset(20.0)
        }
        for view in self.formStackView.arrangedSubviews {
            if view is QuantTextView {
                view.snp.makeConstraints { make in
                    make.leading.trailing.equalToSuperview().inset(marginOffset)
                }
            }
            if view is QuantOTPStackView {
                view.snp.makeConstraints { make in
                    make.centerX.equalToSuperview().offset(-2.5)
                    make.height.equalTo(40.0)
                }
            }
            if view is UILabel {
                view.snp.makeConstraints { make in
                    make.leading.trailing.equalToSuperview().inset(marginOffset)
                }
            }
        }
        self.submitBtn.snp.makeConstraints { make in
            make.height.equalTo(30.0)
            make.leading.equalToSuperview().offset(marginOffset)
            make.trailing.equalToSuperview().offset(-marginOffset)
        }
        self.placeholderview.snp.makeConstraints { make in
            make.leading.trailing.equalToSuperview().inset(30.0)
            make.centerY.centerX.equalToSuperview()
            make.height.equalTo(formHeight)
        }
    }
    
    @objc func onButtonClicked() {
        NavigationCoordinator.moveToNextController(navigationController: self.navigationController ?? UINavigationController(), initiatingController: QuantViewControllers.LoginViewController, option: nil)
    }
    
    @objc func keyboardWillShow(_ notification: NSNotification) {
        self.moveView(notification: notification, keyboardWillShow: true)
    }
        
    @objc func keyboardWillHide(_ notification: NSNotification) {
        self.moveView(notification: notification, keyboardWillShow: false)
    }
    
    private func moveView(notification: NSNotification, keyboardWillShow: Bool) {
        guard let keyboardSize = (notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue else { return }
        let keyboardHeight = keyboardSize.height
        
        // Keyboard's animation duration
        let keyboardDuration = notification.userInfo![UIResponder.keyboardAnimationDurationUserInfoKey] as! Double
        
        // Keyboard's animation curve
        let keyboardCurve = UIView.AnimationCurve(rawValue: notification.userInfo![UIResponder.keyboardAnimationCurveUserInfoKey] as! Int)!

        
        // Change the constant
        if keyboardWillShow {
            let safeAreaExists = (self.view?.window?.safeAreaInsets.bottom != 0) // Check if safe area exists
            let safeAreaheight: CGFloat = 20
            let heightOffset = UIScreen.main.bounds.height - (keyboardHeight + (safeAreaExists ? 0 : safeAreaheight))
            if heightOffset < viewBottomOffset {
                self.placeholderview.snp.remakeConstraints { make in
                    make.leading.trailing.equalToSuperview().inset(30.0)
                    make.centerX.equalToSuperview()
                    make.centerY.equalToSuperview().offset(-(viewBottomOffset - heightOffset))
                    make.height.equalTo(formHeight)
                }
            }
        }else {
            self.placeholderview.snp.remakeConstraints { make in
                make.leading.trailing.equalToSuperview().inset(30.0)
                make.centerY.centerX.equalToSuperview()
                make.height.equalTo(formHeight)
            }
        }
        // Animate the view the same way the keyboard animates
        let animator = UIViewPropertyAnimator(duration: keyboardDuration, curve: keyboardCurve) { [weak self] in
            // Update Constraints
            self?.view.layoutIfNeeded()
        }
        
        // Perform the animation
        animator.startAnimation()
    }

}

extension QuantLoginViewController : QuantOTPDelegate {
    func didChangeValidity(isValid: Bool, otp: String) {
        // Handle the code
    }
}
