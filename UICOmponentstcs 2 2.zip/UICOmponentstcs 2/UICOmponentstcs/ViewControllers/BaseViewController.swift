//
//  BaseViewController.swift
//  UICOmponentstcs
//
//  Created by Bishwajit Dutta on 07/02/23.
//

import UIKit

typealias QuantBaseViewController = QuantViewControllerProtocol & AppBaseViewController

protocol QuantViewControllerProtocol {
    func setupUI()
    func layoutUI()
}

class AppBaseViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.isHidden = true
        self.view.backgroundColor = UIColor.white
    }

}
