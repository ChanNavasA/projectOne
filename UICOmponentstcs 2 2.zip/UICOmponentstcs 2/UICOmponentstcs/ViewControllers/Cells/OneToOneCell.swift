//
//  OneToOneCell.swift
//  QuantExpo
//
//  Created by Local User on 06/02/23.
//

import UIKit

class OneToOneCell: UICollectionViewCell {
    //MARK: Properities
    
    static let cellIdentifier = "OneToOneCell"
    @IBOutlet weak var bgView: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override public func layoutSubviews() {
        super.layoutSubviews()
        bgView.layer.cornerRadius = 10
        //Added shadow
    }
    

}
