//
//  BoothCollectionViewCell.swift
//  QuantExpo
//
//  Created by Local User on 04/02/23.
//

import UIKit

class BoothCollectionViewCell: UICollectionViewCell {

    //MARK: Properities
    
    static let cellIdentifier = "BoothCell"
    
    @IBOutlet weak var boothName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
