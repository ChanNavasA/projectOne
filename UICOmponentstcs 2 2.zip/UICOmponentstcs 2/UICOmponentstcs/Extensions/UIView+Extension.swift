//
//  UIView+Extension.swift
//  QuantExpo
//
//  Created by Local User on 04/02/23.
//

import UIKit
import SnapKit

extension UIView {
    func addShadow(){
        self.layer.shadowColor = UIColor.red.cgColor
        self.layer.shadowOpacity = 0.5
        self.layer.shadowRadius = 2.0
        self.layer.shadowOffset = CGSizeMake(1.0, 10)
        self.layer.masksToBounds = true
    }
}

@IBDesignable class CurvedHeaderView: UIView {
    
    @IBInspectable var startColor: UIColor = UIColor.white
    @IBInspectable var endColor: UIColor = UIColor.white
    
    var curvedLayer = CAShapeLayer()
    
    override func draw(_ rect: CGRect) {
        self.layer.insertSublayer(createGradiantViewCurve(rect: rect), at: 0)
    }
    
    func createGradiantViewCurve(rect: CGRect) -> CAGradientLayer {
        let path = UIBezierPath()
        path.move(to: CGPoint(x: 0, y: 0))
        path.addLine(to: CGPoint(x: rect.width, y: 0))
        path.addLine(to: CGPoint(x: rect.width, y: rect.height / 1.2))
        path.addLine(to: CGPoint(x: 0, y: rect.height / 1.2))
        path.move(to: CGPoint(x: 0, y: rect.height / 1.2))
        path.addCurve(to: CGPoint(x: rect.width, y: rect.height / 1.2), controlPoint1: CGPoint(x: rect.height / 1.2 + 30, y: rect.height / 1.2 + 30), controlPoint2: CGPoint(x: rect.height / 1.2 + 50, y: rect.height / 1.2 + 50))
        curvedLayer.path = path.cgPath
        let gradiant =  CAGradientLayer()
        gradiant.frame = path.bounds
        gradiant.colors = [startColor.cgColor, endColor.cgColor]
        gradiant.startPoint = CGPoint(x: 0.0, y: 0.5)
        gradiant.endPoint = CGPoint(x: 1.0, y: 0.5)

        curvedLayer.frame = rect
        gradiant.mask = curvedLayer
        return gradiant
    }

}

@IBDesignable class NavigationView: UIView {
    @IBInspectable var startColor: UIColor = UIColor.white
    @IBInspectable var endColor: UIColor = UIColor.white
    @IBInspectable var buttonHeight: CGFloat = 0.0
    @IBInspectable var buttonWidth: CGFloat = 0.0
    @IBInspectable var image: UIImage = UIImage()
    @IBInspectable var titleLabelText: String = ""
    
    private var backButton: UIButton = {
        let button = UIButton()
        button.addTarget(self, action: #selector(pressed), for: .touchUpInside)
        return button
    }()
    
    private var titleLabel: UILabel = {
        let label = UILabel()
        return label
    }()
    
    
    override func draw(_ rect: CGRect) {
        self.layer.insertSublayer(createNavigationView(rect: rect), at: 0)
        self.addSubview(backButton)
        self.addSubview(titleLabel)
        self.layoutUI()
    }
    
    private func createNavigationView(rect: CGRect) -> CAGradientLayer{
        let gradiant =  CAGradientLayer()
        gradiant.frame = rect
        gradiant.colors = [startColor.cgColor, endColor.cgColor]
        gradiant.startPoint = CGPoint(x: 0.0, y: 0.5)
        gradiant.endPoint = CGPoint(x: 1.0, y: 0.5)
        return gradiant
    }
    @objc func pressed() {
        print("pressed")
        NotificationCenter.default
                    .post(name:           NSNotification.Name("popToHomeViewController"),
                     object: nil)
        
//        window?.navigationController?.popViewController(animated: false)
        ////        let viewControllers: [UIViewController] = self.navigationController!.viewControllers
        ////        for aViewController in viewControllers {
        ////            if aViewController is QuantMenuPageViewController {
        ////                self.navigationController!.popToViewController(aViewController, animated: true)
        //            }
        //        }
    }
    
    private func layoutUI() {

        self.backButton.setBackgroundImage(image, for: UIControl.State.normal)
        
        self.titleLabel.text = titleLabelText
        titleLabel.textColor = .white
        titleLabel.textAlignment = .center
        titleLabel.font = UIFont.boldSystemFont(ofSize: 20.0)
        
        self.backButton.snp.makeConstraints { make in
            make.leading.equalToSuperview().offset(20)
            make.width.equalTo(buttonWidth)
            make.height.equalTo(buttonHeight)
            make.bottom.equalToSuperview().offset(-20)
        }
        self.titleLabel.snp.makeConstraints{ make in
            make.leading.equalTo(self.backButton.snp.trailing).offset(20)
            make.trailing.equalToSuperview()
            make.height.equalTo(buttonHeight)
            make.bottom.equalToSuperview().offset(-20)
        }
        
    }
}

//@IBDesignable class CurvedHeaderView: UIView {
//
//
//    var curvedLayer = CAShapeLayer()
//    var curvedLayer1 = CAShapeLayer()
//    var curvedLayerTop = CAShapeLayer()
//
//    override func draw(_ rect: CGRect) {
//        self.layer.insertSublayer(createGradiantViewTop(rect: rect), at: 0)
//        self.layer.insertSublayer(createGradiantView(rect: rect), at: 1)
//        self.layer.insertSublayer(createGradiantView1(rect: rect), at: 2)
//    }
//
//    func createGradiantView(rect: CGRect) -> CAGradientLayer {
//        let path = UIBezierPath()
//        path.move(to: CGPoint(x: 0, y: 0))
//        path.addLine(to: CGPoint(x: rect.width, y: 0))
//        path.addLine(to: CGPoint(x: rect.width, y: rect.height / 1.2))
//        path.addLine(to: CGPoint(x: 0, y: rect.height / 1.2))
//        path.move(to: CGPoint(x: 0, y: rect.height / 1.2))
//        path.addCurve(to: CGPoint(x: rect.width + 60, y: rect.height / 1.2), controlPoint1: CGPoint(x: rect.height / 1.2 + 60, y: rect.height / 1.2 + 60), controlPoint2: CGPoint(x: rect.height / 1.2 + 60, y: rect.height / 1.2 + 60))
//        path.close()
//        curvedLayer.path = path.cgPath
//        let gradiant =  CAGradientLayer()
//        gradiant.frame = path.bounds
//        gradiant.colors = [UIColor.red.cgColor, UIColor.yellow.cgColor]
//        curvedLayer.frame = rect
//        gradiant.mask = curvedLayer
//        return gradiant
//    }
//
//    func createGradiantView1(rect: CGRect) -> CAGradientLayer {
//        let path = UIBezierPath()
//        path.move(to: CGPoint(x: 0, y: 0))
//        path.addLine(to: CGPoint(x: rect.width, y: 0))
//        path.addLine(to: CGPoint(x: rect.width, y: rect.height / 1.2))
//        path.addLine(to: CGPoint(x: 0, y: rect.height / 1.2))
//        path.move(to: CGPoint(x: 0, y: rect.height / 1.2))
//        path.addCurve(to: CGPoint(x: rect.width, y: rect.height / 1.2), controlPoint1: CGPoint(x: rect.height / 1.2 + 30, y: rect.height / 1.2 + 30), controlPoint2: CGPoint(x: rect.height / 1.2 + 50, y: rect.height / 1.2 + 50))
//        curvedLayer1.path = path.cgPath
//        let gradiant =  CAGradientLayer()
//        gradiant.frame = path.bounds
//        gradiant.colors = [UIColor.blue.cgColor, UIColor.green.cgColor]
//        curvedLayer1.frame = rect
//        gradiant.mask = curvedLayer1
//        return gradiant
//    }
//
//    func createGradiantViewTop(rect: CGRect) -> CAGradientLayer {
//        let path = UIBezierPath()
//        path.move(to: CGPoint(x: 0, y: 0))
//        path.addLine(to: CGPoint(x: rect.width, y: 0))
//        path.addLine(to: CGPoint(x: rect.width, y: rect.height / 1.18))
//        path.addLine(to: CGPoint(x: 0, y: rect.height / 1.18))
//        path.move(to: CGPoint(x: 0, y: rect.height / 1.18))
//        path.addCurve(to: CGPoint(x: rect.width + 50, y: rect.height / 1.15), controlPoint1: CGPoint(x: rect.height / 1.18 + 70, y: rect.height / 1.18 + 70), controlPoint2: CGPoint(x: rect.height / 1.18 + 70, y: rect.height / 1.18 + 70))
//        curvedLayerTop.path = path.cgPath
//        let gradiant =  CAGradientLayer()
//        gradiant.frame = path.bounds
//        gradiant.colors = [UIColor.blue.cgColor, UIColor.red.cgColor]
//        curvedLayerTop.frame = rect
//        gradiant.mask = curvedLayerTop
//        return gradiant
//    }
//
//}
