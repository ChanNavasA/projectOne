//
//  QuantLoginViewModel.swift
//  UICOmponentstcs
//
//  Created by Bishwajit Dutta on 07/02/23.
//

import UIKit

class QuantLoginViewModel: NSObject {

}
