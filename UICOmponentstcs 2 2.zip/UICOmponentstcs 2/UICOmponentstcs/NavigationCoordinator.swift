//
//  NavigationCoordinator.swift
//  UICOmponentstcs
//
//  Created by Bishwajit Dutta on 07/02/23.
//

import UIKit

enum QuantViewControllers : String {
    case LoginViewController = "Login"
    case MenuPageViewController = "LandingMenu"
    case ContentLibraryViewController = "ContentLibrary"
    case PlanMeetingViewController = "PlanMeeting"
    case BoothViewController = "Booth"
    case OneToOneMeetingViewController = "OneToOnePlanning"
}

class NavigationCoordinator: NSObject {
    static let loginWorkFlow = ["Login", "LandingMenu"]
    // Both the workflow will have few more screens will differenciate using option selected
    static let menuWorkFlowMeeting = ["LandingMenu", "PlanMeeting", "OneToOnePlanning"]
    static let menuWorkFlowContentLibrary = ["LandingMenu", "Booth"]
    static let menuWorkFlowOneToOnePlanning = ["PlanMeeting", "OneToOnePlanning"]
    
    static func moveToNextController(navigationController : UINavigationController, initiatingController : QuantViewControllers, option: Any?) {
        var nextController : UIViewController?
        switch initiatingController {
        case QuantViewControllers.LoginViewController:
            let nextControllerName = findNextController(initiatingController: QuantViewControllers.LoginViewController, workflow: loginWorkFlow)
            nextController = getViewController(controller: nextControllerName ?? .LoginViewController)
            break
        case QuantViewControllers.MenuPageViewController:
            if let option = option as? Int {
                if option == 1 {
                    let nextControllerName = findNextController(initiatingController: QuantViewControllers.LoginViewController, workflow: menuWorkFlowContentLibrary)
                    nextController = getViewController(controller: nextControllerName ?? .LoginViewController)
                } else if option == 2 {
                    let nextControllerName = findNextController(initiatingController: QuantViewControllers.LoginViewController, workflow: menuWorkFlowMeeting)
                    nextController = getViewController(controller: nextControllerName ?? .LoginViewController)
                }
            }
            break
        case QuantViewControllers.OneToOneMeetingViewController:
            if let option = option as? Int {
                if option == 1 {
                    let nextControllerName = findNextController(initiatingController: QuantViewControllers.PlanMeetingViewController, workflow: menuWorkFlowMeeting)
                    nextController = getViewController(controller: nextControllerName ?? .LoginViewController)
                } else if option == 2 {
                    let nextControllerName = findNextController(initiatingController: QuantViewControllers.LoginViewController, workflow: menuWorkFlowMeeting)
                    nextController = getViewController(controller: nextControllerName ?? .LoginViewController)
                }
            }
            break
        default:
            break
            // DO nothing as of now
        }
        if nextController != nil {
            navigationController.pushViewController(nextController!, animated: false)
        }
    }
    
    fileprivate static func getViewController(controller : QuantViewControllers) -> UIViewController? {
        switch controller {
        case QuantViewControllers.LoginViewController:
            return QuantLoginViewController.init()
        case QuantViewControllers.MenuPageViewController:
            return QuantMenuPageViewController.init()
        case QuantViewControllers.ContentLibraryViewController:
            return QuantContentLibraryViewController.init()
        case QuantViewControllers.PlanMeetingViewController:
            return QuantPlanMeetingViewController.init()
        case QuantViewControllers.BoothViewController:
            return QuantExpoBoothViewController.init()
        case QuantViewControllers.OneToOneMeetingViewController:
            return QuantExpoOneToOneViewController.init()
        }
    }
    
    fileprivate static func findNextController(initiatingController : QuantViewControllers, workflow: [String]) -> QuantViewControllers? {
        let itemIndex = workflow.firstIndex(of: initiatingController.rawValue)
        // Reached the last of workflow
        if itemIndex == workflow.count - 1 { return nil }
        return QuantViewControllers.init(rawValue: workflow[(itemIndex ?? 0 ) + 1])
    }
    
}
